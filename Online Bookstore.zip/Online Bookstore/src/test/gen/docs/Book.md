

# Book


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**ISBN** | **String** |  |  [optional] |
|**title** | **String** |  |  [optional] |
|**publicationYear** | **Integer** |  |  [optional] |
|**price** | **BigDecimal** |  |  [optional] |



