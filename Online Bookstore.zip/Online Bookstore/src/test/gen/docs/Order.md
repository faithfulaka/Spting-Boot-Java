

# Order


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Integer** |  |  [optional] |
|**datetime** | **OffsetDateTime** |  |  [optional] |
|**customerName** | **String** |  |  [optional] |



