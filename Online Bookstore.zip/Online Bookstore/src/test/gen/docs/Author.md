

# Author


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Integer** |  |  [optional] |
|**name** | **String** |  |  [optional] |
|**birthyear** | **Integer** |  |  [optional] |
|**nationality** | **String** |  |  [optional] |



